#define TRUE  (int)1
#define FALSE (int)0
#define BUF_SIZE        8192
#define BB_BANNER
#define RESERVE_BB_BUFFER(buffer,len)  static          char buffer[len]
#define RELEASE_BB_BUFFER(buffer)      ((void)0)
//#define perror_msg_and_die(msg) {puts(msg); exit(FALSE);}
#define perror_msg_and_die(msg) 
//#define error_msg_and_die(msg,...) perror_msg_and_die(msg)
#define error_msg_and_die(msg,...) 
#define show_usage() exit(0)
#define BB_FEATURE_REMOTE_LOG
#define BB_FEATURE_IPC_SYSLOG


struct syslog_conf {
	int mail_enable;
	int mail_log_full;
    char dos_thresholds[4];//20-100
	char mail_server[128];
	char mail_sender[128];
	char mail_receiver[128];
	char mail_subject[128];
	char mail_user[128];
	char mail_passwd[128];	
	char mail_subject_alert[128];
	int mail_time;
	int mail_storm;
	char TZ[8];
	char daylight[2];
	char mail_keyword[128];
    int log_enable;//new
    int relay_level;//new
	char log_host[32];
	char buf_size[32]; // open buffer

	//char buffer_keyword[256];
	//char console_keyword[256];
	//char host_keyword[256];
    int buffer_level;
    int console_level;
    int host_level;
};
